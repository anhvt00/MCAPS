#!/bin/sh
#PBS -v PATH
#$ -v PATH


para=$1
cd /data5/data/webcomp/web-session/1640679087
./1640679087.fas.0.47833-bl.pl 0 $para &
./1640679087.fas.0.47833-bl.pl 1 $para &
./1640679087.fas.0.47833-bl.pl 2 $para &
./1640679087.fas.0.47833-bl.pl 3 $para &
wait

